/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50532
Source Host           : localhost:3306
Source Database       : alg

Target Server Type    : MYSQL
Target Server Version : 50532
File Encoding         : 65001

Date: 2013-12-13 16:05:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for attribute
-- ----------------------------
DROP TABLE IF EXISTS `attribute`;
CREATE TABLE `attribute` (
  `ATTRIBUTE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ATTRIBUTE_NAME` varchar(255) DEFAULT NULL,
  `TYPE_ID` int(11) DEFAULT NULL,
  `STATUS` int(1) DEFAULT '0',
  PRIMARY KEY (`ATTRIBUTE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of attribute
-- ----------------------------
INSERT INTO `attribute` VALUES ('-9', 'Country', '-1', '0');
INSERT INTO `attribute` VALUES ('-8', 'Administrative Area', '-1', '0');
INSERT INTO `attribute` VALUES ('-7', 'Sublocality', '-1', '0');
INSERT INTO `attribute` VALUES ('-6', 'Locality', '-1', '0');
INSERT INTO `attribute` VALUES ('-5', 'Postal Code', '-1', '0');
INSERT INTO `attribute` VALUES ('-4', 'Street Number', '-1', '0');
INSERT INTO `attribute` VALUES ('-3', 'Route', '-1', '0');
INSERT INTO `attribute` VALUES ('-2', 'Lng', '-3', '0');
INSERT INTO `attribute` VALUES ('-1', 'Lat', '-3', '0');
INSERT INTO `attribute` VALUES ('1', 'Nome', '-1', '0');
INSERT INTO `attribute` VALUES ('2', 'Idade', '-2', '0');
INSERT INTO `attribute` VALUES ('3', 'Data de Nascimento', '-6', '0');
INSERT INTO `attribute` VALUES ('4', 'CPF', '-2', '0');
INSERT INTO `attribute` VALUES ('5', 'Localizacao', '-9', '0');
INSERT INTO `attribute` VALUES ('6', 'Contrato', '3', '0');
INSERT INTO `attribute` VALUES ('7', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('8', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('9', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('10', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('11', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('12', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('13', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('14', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('15', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('16', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('17', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('18', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('19', 'llz', '-1', '0');
INSERT INTO `attribute` VALUES ('20', 'nome', '-2', '0');
INSERT INTO `attribute` VALUES ('21', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('22', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('23', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('24', 'nome', '-9', '0');
INSERT INTO `attribute` VALUES ('25', 'bin', '-4', '0');
INSERT INTO `attribute` VALUES ('26', 'A', '-9', '0');
INSERT INTO `attribute` VALUES ('27', 'A', '-9', '0');
INSERT INTO `attribute` VALUES ('28', 'B', '-9', '0');
INSERT INTO `attribute` VALUES ('29', 'G', '-9', '0');
INSERT INTO `attribute` VALUES ('30', 'As', '-8', '0');
INSERT INTO `attribute` VALUES ('31', 'B', '-9', '0');
INSERT INTO `attribute` VALUES ('32', 'X', '-9', '0');
INSERT INTO `attribute` VALUES ('33', 'AS', '-9', '0');
INSERT INTO `attribute` VALUES ('34', 'A', '-9', '0');
INSERT INTO `attribute` VALUES ('35', 'a', '-9', '0');
INSERT INTO `attribute` VALUES ('36', 'b', '-9', '0');
INSERT INTO `attribute` VALUES ('37', 'g', '-9', '0');
INSERT INTO `attribute` VALUES ('38', 'x', '1', '0');
INSERT INTO `attribute` VALUES ('39', 'contas', '15', '0');
INSERT INTO `attribute` VALUES ('40', 'Nome', '-1', '0');
INSERT INTO `attribute` VALUES ('41', 'CÃ³digo', '-3', '0');
INSERT INTO `attribute` VALUES ('42', 'attr1', '-9', '-1');
INSERT INTO `attribute` VALUES ('43', 'attr2', '-9', '-1');
INSERT INTO `attribute` VALUES ('44', 'fasdf', '-9', '-1');
INSERT INTO `attribute` VALUES ('45', 'a', '-9', '-1');
INSERT INTO `attribute` VALUES ('46', 'b', '-9', '-1');
INSERT INTO `attribute` VALUES ('47', 'CNPJ', '-1', '0');
INSERT INTO `attribute` VALUES ('48', 'LocalizaÃ§Ã£o', '-9', '-1');
INSERT INTO `attribute` VALUES ('49', 'Min. Date', '-6', '0');
INSERT INTO `attribute` VALUES ('50', 'Max.Date', '-6', '0');
INSERT INTO `attribute` VALUES ('51', 'Front Interval', '-2', '0');
INSERT INTO `attribute` VALUES ('52', 'Back Interval', '-3', '0');

-- ----------------------------
-- Table structure for class
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `CLASS_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CLASS_NAME` varchar(255) DEFAULT NULL,
  `STATUS` int(1) DEFAULT '0',
  PRIMARY KEY (`CLASS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of class
-- ----------------------------
INSERT INTO `class` VALUES ('-9', 'Location', '0');
INSERT INTO `class` VALUES ('-8', 'Email', '0');
INSERT INTO `class` VALUES ('-7', 'Currency', '0');
INSERT INTO `class` VALUES ('-6', 'Date', '0');
INSERT INTO `class` VALUES ('-5', 'Stream', '0');
INSERT INTO `class` VALUES ('-4', 'Boolean', '0');
INSERT INTO `class` VALUES ('-3', 'Decimal', '0');
INSERT INTO `class` VALUES ('-2', 'Int', '0');
INSERT INTO `class` VALUES ('-1', 'String', '0');
INSERT INTO `class` VALUES ('1', 'Pessoa', '0');
INSERT INTO `class` VALUES ('2', 'Rebocador', '0');
INSERT INTO `class` VALUES ('3', 'Contrato', '-1');
INSERT INTO `class` VALUES ('9', 'Conta ContÃ¡bil', '-1');
INSERT INTO `class` VALUES ('10', 'Fs', '-1');
INSERT INTO `class` VALUES ('11', 'New Class', '-1');
INSERT INTO `class` VALUES ('12', 'FSD', '-1');
INSERT INTO `class` VALUES ('13', 'FFK', '-1');
INSERT INTO `class` VALUES ('14', 'Patriot', '-1');
INSERT INTO `class` VALUES ('15', 'Conta ContÃ¡bil', '0');
INSERT INTO `class` VALUES ('16', 'Centro de Custo', '0');
INSERT INTO `class` VALUES ('17', 'Cobaia', '0');
INSERT INTO `class` VALUES ('18', 'Pessoa JurÃ­dica', '0');
INSERT INTO `class` VALUES ('19', '@DateValidation', '0');

-- ----------------------------
-- Table structure for class_attribute
-- ----------------------------
DROP TABLE IF EXISTS `class_attribute`;
CREATE TABLE `class_attribute` (
  `CLASS_ID` int(11) DEFAULT NULL,
  `ATTRIBUTE_ID` int(11) DEFAULT NULL,
  KEY `fk_CLASS_ATTRIBUTE_CLASS_1` (`CLASS_ID`),
  KEY `fk_CLASS_ATTRIBUTE_ATTRIBUTE_1` (`ATTRIBUTE_ID`),
  CONSTRAINT `fgxx` FOREIGN KEY (`ATTRIBUTE_ID`) REFERENCES `attribute` (`ATTRIBUTE_ID`),
  CONSTRAINT `fkx` FOREIGN KEY (`CLASS_ID`) REFERENCES `class` (`CLASS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of class_attribute
-- ----------------------------
INSERT INTO `class_attribute` VALUES ('-9', '-1');
INSERT INTO `class_attribute` VALUES ('-9', '-2');
INSERT INTO `class_attribute` VALUES ('9', '35');
INSERT INTO `class_attribute` VALUES ('9', '36');
INSERT INTO `class_attribute` VALUES ('9', '37');
INSERT INTO `class_attribute` VALUES ('14', '38');
INSERT INTO `class_attribute` VALUES ('2', '1');
INSERT INTO `class_attribute` VALUES ('16', '39');
INSERT INTO `class_attribute` VALUES ('17', '45');
INSERT INTO `class_attribute` VALUES ('17', '46');
INSERT INTO `class_attribute` VALUES ('15', '40');
INSERT INTO `class_attribute` VALUES ('15', '41');
INSERT INTO `class_attribute` VALUES ('18', '47');
INSERT INTO `class_attribute` VALUES ('1', '2');
INSERT INTO `class_attribute` VALUES ('1', '1');
INSERT INTO `class_attribute` VALUES ('1', '3');
INSERT INTO `class_attribute` VALUES ('1', '4');
INSERT INTO `class_attribute` VALUES ('1', '5');
INSERT INTO `class_attribute` VALUES ('19', '49');
INSERT INTO `class_attribute` VALUES ('19', '50');
INSERT INTO `class_attribute` VALUES ('19', '51');
INSERT INTO `class_attribute` VALUES ('19', '52');

-- ----------------------------
-- Table structure for list_object
-- ----------------------------
DROP TABLE IF EXISTS `list_object`;
CREATE TABLE `list_object` (
  `LIST_ID` varchar(255) NOT NULL,
  `OBJECT_ID` int(11) DEFAULT NULL,
  KEY `ZXS` (`LIST_ID`),
  KEY `XCD` (`OBJECT_ID`),
  CONSTRAINT `fxdc` FOREIGN KEY (`OBJECT_ID`) REFERENCES `object` (`OBJECT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of list_object
-- ----------------------------
INSERT INTO `list_object` VALUES ('34-6', '35');
INSERT INTO `list_object` VALUES ('65-39', '63');
INSERT INTO `list_object` VALUES ('65-39', '64');

-- ----------------------------
-- Table structure for module
-- ----------------------------
DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `MODULE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `MODULE_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MODULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of module
-- ----------------------------

-- ----------------------------
-- Table structure for module_class
-- ----------------------------
DROP TABLE IF EXISTS `module_class`;
CREATE TABLE `module_class` (
  `MODULE_ID` int(11) DEFAULT NULL,
  `CLASS_ID` int(11) DEFAULT NULL,
  KEY `fk_MODULE_CLASS_MODULE_1` (`MODULE_ID`),
  KEY `fk_MODULE_CLASS_CLASS_1` (`CLASS_ID`),
  CONSTRAINT `fk_MODULE_CLASS_CLASS_1` FOREIGN KEY (`CLASS_ID`) REFERENCES `class` (`CLASS_ID`),
  CONSTRAINT `fk_MODULE_CLASS_MODULE_1` FOREIGN KEY (`MODULE_ID`) REFERENCES `module` (`MODULE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of module_class
-- ----------------------------

-- ----------------------------
-- Table structure for object
-- ----------------------------
DROP TABLE IF EXISTS `object`;
CREATE TABLE `object` (
  `OBJECT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `CLASS_ID` int(11) DEFAULT NULL,
  `OBJECT_STATUS` tinyint(1) NOT NULL DEFAULT '0',
  `OBJECT_NATURALID` int(11) NOT NULL,
  PRIMARY KEY (`OBJECT_ID`),
  KEY `fk_OBJECT_CLASS_1` (`CLASS_ID`),
  CONSTRAINT `fk_OBJECT_CLASS_1` FOREIGN KEY (`CLASS_ID`) REFERENCES `class` (`CLASS_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of object
-- ----------------------------
INSERT INTO `object` VALUES ('34', '1', '0', '1');
INSERT INTO `object` VALUES ('35', '3', '0', '1');
INSERT INTO `object` VALUES ('36', '3', '0', '2');
INSERT INTO `object` VALUES ('37', '3', '-1', '1');
INSERT INTO `object` VALUES ('38', '3', '0', '3');
INSERT INTO `object` VALUES ('39', '3', '0', '4');
INSERT INTO `object` VALUES ('40', '2', '-1', '0');
INSERT INTO `object` VALUES ('41', '2', '0', '1');
INSERT INTO `object` VALUES ('42', '2', '0', '2');
INSERT INTO `object` VALUES ('43', '3', '0', '5');
INSERT INTO `object` VALUES ('44', '3', '0', '6');
INSERT INTO `object` VALUES ('45', '3', '0', '7');
INSERT INTO `object` VALUES ('46', '3', '0', '8');
INSERT INTO `object` VALUES ('47', '3', '0', '9');
INSERT INTO `object` VALUES ('48', '3', '0', '10');
INSERT INTO `object` VALUES ('49', '3', '0', '11');
INSERT INTO `object` VALUES ('50', '3', '0', '12');
INSERT INTO `object` VALUES ('51', '3', '0', '13');
INSERT INTO `object` VALUES ('52', '3', '0', '14');
INSERT INTO `object` VALUES ('53', '14', '0', '0');
INSERT INTO `object` VALUES ('54', '15', '-1', '0');
INSERT INTO `object` VALUES ('55', '15', '-1', '1');
INSERT INTO `object` VALUES ('56', '15', '-1', '2');
INSERT INTO `object` VALUES ('57', '15', '-1', '3');
INSERT INTO `object` VALUES ('58', '15', '-1', '4');
INSERT INTO `object` VALUES ('59', '15', '-1', '5');
INSERT INTO `object` VALUES ('60', '15', '-1', '6');
INSERT INTO `object` VALUES ('61', '15', '-1', '7');
INSERT INTO `object` VALUES ('62', '15', '-1', '8');
INSERT INTO `object` VALUES ('63', '15', '0', '9');
INSERT INTO `object` VALUES ('64', '15', '0', '10');
INSERT INTO `object` VALUES ('65', '16', '0', '0');
INSERT INTO `object` VALUES ('66', '18', '-1', '0');
INSERT INTO `object` VALUES ('67', '18', '0', '1');

-- ----------------------------
-- Table structure for object_attributes
-- ----------------------------
DROP TABLE IF EXISTS `object_attributes`;
CREATE TABLE `object_attributes` (
  `OBJECT_ID` int(11) DEFAULT NULL,
  `ATTRIBUTE_ID` int(11) DEFAULT NULL,
  `VALUE` blob,
  `LIST_ID` varchar(255) DEFAULT NULL,
  KEY `fk_OBJECT_ATTRIBUTES_OBJECT_1` (`OBJECT_ID`),
  KEY `fk_OBJECT_ATTRIBUTES_ATTRIBUTE_1` (`ATTRIBUTE_ID`),
  KEY `FK_OB` (`LIST_ID`),
  CONSTRAINT `fk_OBJECT_ATTRIBUTES_ATTRIBUTE_1` FOREIGN KEY (`ATTRIBUTE_ID`) REFERENCES `attribute` (`ATTRIBUTE_ID`),
  CONSTRAINT `fk_OBJECT_ATTRIBUTES_OBJECT_1` FOREIGN KEY (`OBJECT_ID`) REFERENCES `object` (`OBJECT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of object_attributes
-- ----------------------------
INSERT INTO `object_attributes` VALUES ('34', '2', 0x30, '');
INSERT INTO `object_attributes` VALUES ('34', '1', 0x4C756361737878, '');
INSERT INTO `object_attributes` VALUES ('34', '3', 0x6E756C6C, '');
INSERT INTO `object_attributes` VALUES ('34', '4', 0x30, '');
INSERT INTO `object_attributes` VALUES ('34', '5', 0x7B726F7574653D2C207374726565744E756D6265723D2C20706F7374616C436F64653D2C206C6F63616C6974793D2C207375626C6F63616C6974793D2C2061646D696E697374726174697665417265613D7D, '');
INSERT INTO `object_attributes` VALUES ('34', '6', 0x6E756C6C, '34-6');
INSERT INTO `object_attributes` VALUES ('35', '1', 0x524A3130323330, '');
INSERT INTO `object_attributes` VALUES ('36', '1', 0x53445230323033303430, '');
INSERT INTO `object_attributes` VALUES ('37', '1', '', '');
INSERT INTO `object_attributes` VALUES ('38', '1', '', '');
INSERT INTO `object_attributes` VALUES ('39', '1', 0x4F4F50, '');
INSERT INTO `object_attributes` VALUES ('40', '1', 0x494F41504F515545, '');
INSERT INTO `object_attributes` VALUES ('41', '1', 0x4A494D4D59, '');
INSERT INTO `object_attributes` VALUES ('42', '1', 0x4A494D4D5932, '');
INSERT INTO `object_attributes` VALUES ('43', '1', 0x5A5A5844535843, '');
INSERT INTO `object_attributes` VALUES ('44', '1', 0x524A3333303930, '');
INSERT INTO `object_attributes` VALUES ('45', '1', 0x524A33333039306661736466, '');
INSERT INTO `object_attributes` VALUES ('46', '1', 0x524A333330393073646173, '');
INSERT INTO `object_attributes` VALUES ('47', '1', 0x524A33333039307878, '');
INSERT INTO `object_attributes` VALUES ('48', '1', 0x524A33333039306661736466, '');
INSERT INTO `object_attributes` VALUES ('49', '1', 0x524A3333303930, '');
INSERT INTO `object_attributes` VALUES ('50', '1', 0x524A33333132333132, '');
INSERT INTO `object_attributes` VALUES ('51', '1', 0x524A3334333233, '');
INSERT INTO `object_attributes` VALUES ('52', '1', 0x4C7563617330323073436F6E78, '');
INSERT INTO `object_attributes` VALUES ('53', '38', 0x6E756C6C, '53-38');
INSERT INTO `object_attributes` VALUES ('62', '40', 0x6661736466, null);
INSERT INTO `object_attributes` VALUES ('62', '41', 0x66617364666173, null);
INSERT INTO `object_attributes` VALUES ('63', '40', 0x6661736466, null);
INSERT INTO `object_attributes` VALUES ('63', '41', 0x313233313233, null);
INSERT INTO `object_attributes` VALUES ('64', '40', 0x66617364666666, null);
INSERT INTO `object_attributes` VALUES ('64', '41', 0x33333333, null);
INSERT INTO `object_attributes` VALUES ('65', '39', null, '65-39');
INSERT INTO `object_attributes` VALUES ('66', '47', 0x343332333132333433, null);
INSERT INTO `object_attributes` VALUES ('67', '47', 0x3938393635363332, null);
