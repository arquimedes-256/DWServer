1	Embarcado
2	Manutenção
3	Administrativo
4	Voyage Charter
5	Bareboat
6	Custo de Combustível
7	Fretes e Carretos
8	Materiais
9	Serviços
10	Desp. Gerais Téc. e Manut.
11	Seguros e P&I
12	Portuárias
13	Convés - Cabos
14	Portuárias do Armador
15	SMS
16	Outras Desp. Gerais e Pessoal
17	Outras DGA Filial
18	Desp. Comerc. (Comissões)



insert into 
TB_PRD_GRUPO_CONTA(ID_CONTA,ID_GRUPO_CONTAS)
values(
411510003000000
,18)



SELECT 
					NOME_CONTA_CONTABIL,
					COD_CONTA_CONTABIL,
					MAX(VALOR_LANCAMENTO) REALIZADO
					FROM PRD
					where COD_CONTA_CONTABIL IN 
					(
						SELECT ID_CONTA
						FROM TB_PRD_GRUPO_CONTA WHERE ID_GRUPO_CONTAS = 1
					)
					GROUP BY
					NOME_CONTA_CONTABIL,
					COD_CONTA_CONTABIL

select * from tb_contrato where num_contrato = 'SEP000172' 

update TB_CONTRATO set dt_fim = TO_DATE('31/12/2013', 'dd/mm/yyyy'), situacao = 'A' where num_contrato = 'SEP000172' – para 31/12/2013.

select * from TB_PRD_GRUPO_CONTA where id_conta = 421030002000000

--select * from TB_PRD_GRUPO--