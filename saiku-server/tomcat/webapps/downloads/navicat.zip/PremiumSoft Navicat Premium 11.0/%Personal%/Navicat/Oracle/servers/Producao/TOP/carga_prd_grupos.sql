declare
   type array_t is varray(1) of number;
   array array_t := array_t(411420002000000);
/*
53	Josevaldo	P	STR
54	Edson	P	STR
55	Carlos	P	STR
56	Thiago	P	STR
57	Bruno	P	STR
58	Leandro	P	STR

*/
begin
   for i in 1..array.last loop
       --dbms_output.put_line(array(i));
			INSERT INTO TB_PRD_GRUPO_CONTA(ID_GRUPO_CONTAS,ID_CONTA) VALUES(56,array(i));
			INSERT INTO TB_PRD_GRUPO_CONTA(ID_GRUPO_CONTAS,ID_CONTA) VALUES(57,array(i));
			INSERT INTO TB_PRD_GRUPO_CONTA(ID_GRUPO_CONTAS,ID_CONTA) VALUES(58,array(i));
   end loop;
end;