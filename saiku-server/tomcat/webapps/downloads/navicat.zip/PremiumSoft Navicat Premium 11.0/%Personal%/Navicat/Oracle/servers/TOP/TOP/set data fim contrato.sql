update TB_CONTRATO set DT_FIM = to_date('30/12/2014','dd/mm/yyyy'), SITUACAO = 'A' where 
NUM_CONTRATO in( 'SEP000159')

