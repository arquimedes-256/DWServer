select id_ano,ID_MES,	ID_ATIVO_SYMBOL,
count(*) from x.mf_fato GROUP BY ID_ANO,ID_MES,ID_ATIVO_SYMBOL

select count(*) from x.mf_fato 
/*
*/
delete from x.mf_fato where id_ano = 2007 and id_mes =3 and id_ativo_symbol = 'PETRD47'

SHOW columns from mf_fato
