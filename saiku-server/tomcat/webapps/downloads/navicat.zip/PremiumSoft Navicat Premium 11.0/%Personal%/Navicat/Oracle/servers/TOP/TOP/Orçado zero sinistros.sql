-- sinitros
BEGIN
	for conta in (
					select * 
								from "DW_contacontabil" where ID_CONTA_CONTABIL 
					in(412510001100000,
							412510001200000,
							412510001300000,
							412510001400000,
							412510001500000,
							412510001600000,
							412510001700000,
							412510001810000,
							412510001820000,
							412510001830000,
							412510001900000,
							412510002000000,
							412510002100000,
							412510002200000)
		)
	loop
		for filial in (select * from "DW_filial")
		loop
			for ano in 2013..2014
			loop
				for mes in 1..12
				loop
					insert into 
							TB_PRD_ORCAMENTO(ID_CONTA_CONTABIL,FILIAL_ORIGEM,ANO,MES,VLR_ORCADO)
								values(conta.id_conta_contabil,filial.sigla_filial,ano,mes,0);
				end loop;
			end loop;
		end loop;
	end loop;
end;
