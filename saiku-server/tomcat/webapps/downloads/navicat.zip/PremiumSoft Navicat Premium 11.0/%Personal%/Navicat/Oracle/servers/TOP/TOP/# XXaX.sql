SELECT
	*
FROM
	(
		SELECT
			*
		FROM
			(
				SELECT
					xxx.ano,
xxx.mes,
					xxx.ID_CONTA_CONTABIL,
					xxx.FILIAL_ALOCACAO,
					XXX.ORCADO2014,
					XXX.REALIZADO
				FROM
					DEBUG_STABLE_GRUPOMASTER xxx
				UNION ALL
					SELECT
						FULL_TABLE.ano,
						FULL_TABLE.MES,
						FULL_TABLE.id_conta_contabil,
						FULL_TABLE.filial_alocacao,
						0,
						FULL_TABLE.VLR_REALIZADO
					FROM
						FULL_TABLE
			)
		WHERE
			FILIAL_ALOCACAO = 'MAC'
		AND ID_CONTA_CONTABIL = 412210002000000 --and NOME_ULTRAGRUPO = '-'
		--AND mes = 7
		AND ano = 2013
	)
WHERE
	ROWNUM < 100