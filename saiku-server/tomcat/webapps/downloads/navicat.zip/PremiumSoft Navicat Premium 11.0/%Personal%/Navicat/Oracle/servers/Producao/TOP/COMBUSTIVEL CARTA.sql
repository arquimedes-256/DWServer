DECLARE

id_ano number;
id_mes number;
id_consumo varchar(1);

BEGIN
	delete from "DW_sn_afretamento_fato" where tp_consumo is not null;
	FOR U IN (
		SELECT
			DATA,
			SALDO,
			decode((NVL("SALDO",0) + NVL("COMPRA",0) +  NVL("ACERTO_PERDA_DESCARTE",0) + NVL("TRANS_RECEB",0) - NVL("TRANS_FORNEC",0) - NVL("CONS_MCP",0) - NVL("CONS_MCA",0)),0,NULL) SALDO_FINAL,
			COMPRA,
			ACERTO_PERDA_DESCARTE,
			TRANS_RECEB,
			TRANS_FORNEC,
			CONS_MCP,
			CONS_MCA,
			HR_MCP,
			HR_MCA,
			ID_REBOCADOR,
			SIGLA_FILIAL,
			TP_CONSUMO
		FROM
			TB_SIG_COMBUSTIVEL
		WHERE
			DATA IS NOT NULL
	) 
LOOP 

	id_ano := to_char(u.DATA,'YYYY');
	id_mes := to_char(u.DATA,'MM');
	
	if u.tp_consumo like '%Viajando%' THEN
		id_consumo := 'V';
	elsif u.tp_consumo like '%Docando%' THEN
		id_consumo := 'D';
	ELSE
		id_consumo := 'A';
	end if;	

	INSERT INTO "DW_sn_afretamento_fato" (
		ID_ANO,
		ID_MES,
		ID_ANOMES,
		VLR_COMPRA,
		VLR_ACERTO_PERDA_DESCARTE,
		VLR_RECEBIDO,
		VLR_FORNECIDO,
		VLR_CONSUMO_MCA,
		VLR_CONSUMO_MCP,
		VLR_HORA_MCA,
		VLR_HORA_MCP,
		ID_REBOCADOR,
		ID_FILIAL,
		TP_CONSUMO,VLR_SALDO,VLR_SALDOFINAL,ID_DIA_MES
	)
VALUES
	(
		ID_ANO,
		ID_MES,
		(ID_ANO || '/' || ID_MES),
		U.COMPRA,
		U.ACERTO_PERDA_DESCARTE,
		U.TRANS_RECEB,
		U.TRANS_FORNEC,
		U.CONS_MCP,
		U.CONS_MCA,			
		U.HR_MCP,
		U.HR_MCA,
		U.ID_REBOCADOR,
		U.SIGLA_FILIAL,
		id_consumo,u.saldo,u.saldo_final,TO_CHAR(U.DATA,'DD')
	);
END loop;
end;
