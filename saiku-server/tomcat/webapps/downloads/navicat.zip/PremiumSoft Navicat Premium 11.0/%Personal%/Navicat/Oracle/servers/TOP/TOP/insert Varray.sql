declare
   type array_t is table of number;
   array array_t := 
			array_t(412510001100000,
					412510001200000,
					412510001300000,
					412510001400000,
					412510001500000,
					412510001600000,
					412510001700000,
					412510001810000,
					412510001820000,
					412510001830000,
					412510001900000,
					412510002100000,
					412510002200000);
	type array_s is table of varchar(255);
	s array_s := array_s(
	'Reparos Sinistro Rebocador Corumbá',
	'Reparos Sinistro Rebocador Aragipe',
	'Reparos Sinistro Rebocador Jatobá',
	'Reparos Sinistro Rebocador Chuí',
	'Reparos Sinistro Rebocador Sauípe',
	'Reparos Sinistro Rebocador Atalaia',
	'Reparos Sinistro Rebocador Caburaí',
	'Reparos Sinistro Rebocador Altaneira',
	'Reparos Sinistro Rebocador Caeté',
	'Reparos Sinistro Rebocador Abrolhos',
	'Reparos Sinistro Rebocador Curitiba',
	'Reparos Sinistro Rebocador Penedo',
	'Reparos Sinistro Rebocador David');
begin
   for i in 1..array.count loop
				insert into "DW_contacontabil"(ID_CONTA_CONTABIL,NOME_CONTA_CONTABIL) values(array(i),s(i));
				--dbms_output.put_line(array(i));
   end loop;
end;