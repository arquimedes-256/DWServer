select * from TB_PRD_GRUPO where NOME_GRUPO like '%Outras DGA Filial%';

select * from TB_PRD_GRUPO_CONTA where ID_GRUPO_CONTAS = 17