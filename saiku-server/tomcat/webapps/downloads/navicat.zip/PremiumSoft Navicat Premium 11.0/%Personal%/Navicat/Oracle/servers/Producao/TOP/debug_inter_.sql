/*select * from "DW_sn_afretamento_fato" where VALOR_AFRETAMENTO is null;

select * from TB_FILIAL where ID_FILIAL = 8
*/
									SELECT
										*
									FROM
										TB_SIG_INTERFATURAMENTO
									WHERE
										(
											46500 BETWEEN DWT_INICIAL * 1000
											AND DWT_FINAL * 1000
										)
									AND(
										(
										ID_CLIENTE = 944
										OR ID_CLIENTE = -1
										)
										--OR ID_CLIENTE IS NOT NULL
									)
									--AND SIGLA_FILIAL = 1
									AND(
										ID_TERMINAL = 152
										OR ID_TERMINAL = -1
										--OR ID_TERMINAL IS NOT NULL
									)
									AND(
										ID_MANOBRA = 9
										OR ID_MANOBRA = -1
										--OR ID_MANOBRA IS NOT NULL
									)
									--AND ROWNUM = 1
									ORDER BY
										DWT_FINAL ASC;

--SELECT * FROM TB_EMPRESA WHERE ID_EMPRESA =	946;