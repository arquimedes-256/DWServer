SELECT * FROM
(
SELECT
	motc.id_operacao,
	motc.id_contrato,
	motc.ind_tp_tarifa,
	motc.id_navio,
	motc.id_local_manobra,
	motc.id_manobra_operacao,
	motc.id_terminal,
	motc.id_tipo_manobra,
	motc.descricao_manobra,
	motc.id_porto,
	motc.descricao_porto,
	motc.descricao_terminal,
	motc.descricao_berco,
	motc.id_moeda,
	CASE
WHEN motc.id_moeda = 2 THEN
	ROUND (
		CASE
		WHEN co.cd_tipo_contrato = 'REBOCADOR' THEN
			DECODE (
				NVL (tp.qtd_media_rebocador, 0),
				0,
				DECODE (
					motc.ind_tp_tarifa,
					'L',
					tp.vlr_liner,
					tp.vlr_tramp
				),
				DECODE (
					motc.ind_tp_tarifa,
					'L',
					tp.vlr_liner,
					tp.vlr_tramp
				) / tp.qtd_media_rebocador
			)
		ELSE
			tp.vlr_liner
		END * NVL (cm.vl_cotacao, 0),
		2
	) --REAL
ELSE
	ROUND (
		CASE
		WHEN co.cd_tipo_contrato = 'REBOCADOR' THEN
			DECODE (
				NVL (tp.qtd_media_rebocador, 0),
				0,
				DECODE (
					motc.ind_tp_tarifa,
					'L',
					tp.vlr_liner,
					tp.vlr_tramp
				),
				DECODE (
					motc.ind_tp_tarifa,
					'L',
					tp.vlr_liner,
					tp.vlr_tramp
				) / tp.qtd_media_rebocador
			)
		ELSE
			tp.vlr_liner
		END,
		2
	)
END 
 VL_TARIFA_PORTO,
 motc.vl_tarifa_contrato,
 motc.vl_desconto_tarifa,
 motc.vl_desconto_manobra,
 motc.id_rebocador,
 r.descricao descricao_rebocador,
 motc.proprio,
 motc.ind_afretamento,
 motc.id_faixa_dwt,
 tp.qtd_media_rebocador,
 motc.ID_AJUSTE_TARIFA
FROM
	vw_manobra_oper_trf_contrato motc,
	vw_tarifa_porto_manobra_filial tp,
	tb_rebocador r,
	tb_cotacao_moeda cm,
	tb_contrato co
WHERE
	motc.id_terminal = tp.id_terminal (+)
AND motc.id_tipo_manobra = tp.id_tipo_manobra (+)
AND motc.id_faixa_dwt = tp.id_faixa_dwt (+)
AND motc.id_filial = tp.id_filial (+)
AND 1 = tp.id_moeda (+)
AND cm.id_moeda = 1 --DOLAR
AND cm.data_cotacao = (
	SELECT
		MAX (data_cotacao)
	FROM
		tb_cotacao_moeda
	WHERE
		id_moeda = 1
)
AND motc.id_rebocador = r.id_rebocador
AND co.id_contrato = motc.id_contrato


)WHERE ROWNUM = 1



SELECT VL_BRUTO_ORIGEM, VL_DESCONTO_ORIGEM, VL_LIQUIDO_ORIGEM, VL_ISS_ORIGEM,
                                 VL_BRUTO_REAL,   VL_DESCONTO_REAL,   VL_LIQUIDO_REAL,   VL_ISS_REAL,
                                 VL_TOTAL_REFERENCIA, VL_TOTAL_DESCONTO_APLICADO
                          FROM TB_CALCULO_OPERACAO T
                          WHERE ID_OPERACAO = 94973


SELECT ID_LOCAL_MANOBRA, ID_MANOBRA_OPERACAO, ID_TERMINAL, ID_TIPO_MANOBRA, DESCRICAO_MANOBRA AS MANOBRA,
                         ID_REBOCADOR, NVL(VL_DESCONTO_MANOBRA,0) VL_DESCONTO_MANOBRA , NVL(VL_DESCONTO_TARIFA, 0) VL_DESCONTO_TARIFA,
                         nvl(VL_TARIFA_PORTO,0) VL_TARIFA_PORTO
                  FROM VW_CALCULO_MANOBRA_TARIFA_BASE
                  WHERE ID_OPERACAO = 94973
												AND ID_AJUSTE_TARIFA 
														IN (SELECT ID_AJUSTE_TARIFA 
																		FROM TB_OPERACAO 
																		WHERE ID_OPERACAO = 94973)
                        AND  (PROPRIO = 'S' OR IND_AFRETAMENTO = 'S')
                  ORDER BY ID_LOCAL_MANOBRA, ID_MANOBRA_OPERACAO, ID_TERMINAL, ID_TIPO_MANOBRA 

SELECT * FROM TB_OPERACAO WHERE ID_OPERACAO = 94981

