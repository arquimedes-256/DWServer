-- 146282	459310001000000	1	2013	203	VIT
DECLARE
	last_cc NUMBER ; last_ano NUMBER ; last_mes NUMBER ; last_filial_origem VARCHAR (255) ;
	last_Vlr number;
BEGIN
DBMS_OUTPUT.enable(10000000);
	FOR x IN (
		SELECT
			*
		FROM
			TB_PRD_ORCAMENTO o
		WHERE
			(
				SELECT
					COUNT (*)
				FROM
					TB_PRD_ORCAMENTO D
				WHERE
					D .ANO = o.ANO
				AND D .MES = o.MES
				AND D .FILIAL_ORIGEM = o.FILIAL_ORIGEM
				AND D .ID_CONTA_CONTABIL = o.ID_CONTA_CONTABIL
			) > 1
		ORDER BY
			FILIAL_ORIGEM,
			ANO,
			mes,
			ID_CONTA_CONTABIL,vlr_orcado
	) 
			loop 

				IF 
x.id_conta_contabil = last_cc 
and x.ano = last_ano 
and x.mes = last_mes
and x.filial_origem = last_filial_origem 
 THEN
					--SYS.DBMS_OUTPUT.PUT_LINE(x.filial_origem ||'    ' || x.id_conta_contabil || '    '|| x.mes|| '   '  || x.ano || '    ' || x.vlr_orcado);
					delete from TB_PRD_ORCAMENTO where ID_ORCAMENTO = x.id_orcamento;
				end if;

				last_cc := x.id_conta_contabil;
				last_ano := x.ano;
				last_mes := x.mes;
				last_filial_origem := x.filial_origem;

			END loop ;
END ;