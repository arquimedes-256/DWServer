--update TB_CONTRATO set situacao = 'A', DT_FIM = to_date('30/06/2014','DD/MM/YYYY') where NUM_CONTRATO = 'RJ1000345'


SDR00785 até 31-12-13 

update TB_CONTRATO set situacao = 'A', 
DT_FIM = to_date('31/12/2014','DD/MM/YYYY') where NUM_CONTRATO = 'RJ1000477'