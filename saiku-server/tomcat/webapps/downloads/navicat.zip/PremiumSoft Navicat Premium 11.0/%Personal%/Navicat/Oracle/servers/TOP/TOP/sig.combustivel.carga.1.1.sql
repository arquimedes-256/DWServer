DECLARE
id_ano number;
id_mes number;
id_consumo varchar(5);
nvl_inicial number;
nvl_final number;
qtd_dias_do_mes number;
BEGIN
	delete from "DW_sn_afretamento_fato" where SISTEMA_ORIGEM = 'COM';
	FOR U IN (
		SELECT
			DATA,
			SALDO,
			(NVL("SALDO",0) + NVL("COMPRA",0) +  NVL("ACERTO_PERDA_DESCARTE",0) + NVL("TRANS_RECEB",0) - NVL("TRANS_FORNEC",0) - NVL("CONS_MCP",0) - NVL("CONS_MCA",0)) SALDO_FINAL,
			COMPRA,
			ACERTO_PERDA_DESCARTE,
			TRANS_RECEB,
			TRANS_FORNEC,
			CONS_MCP,
			CONS_MCA,
			HR_MCP,
			HR_MCA,
			ID_REBOCADOR,
			SIGLA_FILIAL,
			NVL("CONS_MCP",0) + NVL("CONS_MCA",0) CONSUMO,
			TP_CONSUMO,ORIGEM
		FROM
			TB_SIG_COMBUSTIVEL
		WHERE
			DATA IS NOT NULL
		and status = 'A'
	) 
LOOP 

	id_ano := to_char(u.DATA,'YYYY');
	id_mes := to_char(u.DATA,'MM');
BEGIN
	select tp_consumo into id_consumo from "DW_tipoconsumo" where NOME_CONSUMO = u.TP_CONSUMO;
END;
 

	select count(*) into qtd_dias_do_mes from 
		TB_SIG_COMBUSTIVEL out
		where out.ID_REBOCADOR = u.ID_REBOCADOR 
		and to_char(out.data,'MM') = to_char(u."DATA",'MM')
		and to_char(out.data,'YY') = to_char(u."DATA",'YY')
		and out.SIGLA_FILIAL = u.SIGLA_FILIAL;

BEGIN
	select SALDO/qtd_dias_do_mes into nvl_final from 
	TB_SIG_COMBUSTIVEL out
	where out.ID_REBOCADOR = u.ID_REBOCADOR 
	and to_char(out.data,'MM') = to_char(u."DATA",'MM')
	and to_char(out.data,'YY') = to_char(u."DATA",'YY')
	and out.SIGLA_FILIAL = u.SIGLA_FILIAL
	and out."DATA" in 
	(
		select max("DATA") from
			TB_SIG_COMBUSTIVEL inp
			where inp.ID_REBOCADOR = out.ID_REBOCADOR 
			and to_char(inp.data,'MM') = to_char(out.data,'MM')
			and to_char(inp.data,'YY') = to_char(out.data,'YY')
			and inp.SIGLA_FILIAL = out.SIGLA_FILIAL
	) and rownum =1;

	select SALDO/qtd_dias_do_mes into nvl_inicial from 
	TB_SIG_COMBUSTIVEL out
	where out.ID_REBOCADOR = u.ID_REBOCADOR 
	and to_char(out.data,'MM') = to_char(u."DATA",'MM')
	and to_char(out.data,'YY') = to_char(u."DATA",'YY')
	and out.SIGLA_FILIAL = u.SIGLA_FILIAL
	and out."DATA" in 
	(
		select min("DATA") from
			TB_SIG_COMBUSTIVEL inp
			where inp.ID_REBOCADOR = out.ID_REBOCADOR 
			and to_char(inp.data,'MM') = to_char(out.data,'MM')
			and to_char(inp.data,'YY') = to_char(out.data,'YY')
			and inp.SIGLA_FILIAL = out.SIGLA_FILIAL
	) and rownum =1;

end;


	INSERT INTO "DW_sn_afretamento_fato" (
		ID_ANO,
		ID_MES,
		ID_ANOMES,
		VLR_COMPRA,
		VLR_ACERTO_PERDA_DESCARTE,
		VLR_RECEBIDO,
		VLR_FORNECIDO,
		VLR_CONSUMO_MCA,
		VLR_CONSUMO_MCP,
		VLR_HORA_MCA,
		VLR_HORA_MCP,
		ID_REBOCADOR,
		ID_FILIAL,
		TP_CONSUMO,VLR_SALDO,
		VLR_SALDOFINAL,
		ID_DIA_MES,
		VLR_CONSUMO,
		VLR_CONSUMO_LITROS_HORA,
		VLR_SALDO_NVL_INICIAL,
		VLR_SALDO_NVL_FINAL,
		VLR_TRANSFERENCIA,
		SISTEMA_ORIGEM
	)
VALUES
	(
		ID_ANO,
		ID_MES,
		(ID_ANO || '/' || ID_MES),
		DECODE(U.COMPRA, 0, NULL,U.COMPRA),
		U.ACERTO_PERDA_DESCARTE,
		U.TRANS_RECEB,
		U.TRANS_FORNEC,
		DECODE(U.CONS_MCP, 0, NULL,U.CONS_MCP),
		DECODE(U.CONS_MCA, 0, NULL,U.CONS_MCA),			
		DECODE(U.HR_MCA, 0, NULL,U.HR_MCA),
		DECODE(U.HR_MCP, 0, NULL,U.HR_MCP),
		U.ID_REBOCADOR,
		U.SIGLA_FILIAL,
		id_consumo,u.saldo,u.saldo_final,TO_CHAR(U.DATA,'DD'),
		DECODE(U.CONSUMO, 0, NULL,U.CONSUMO),
		(U.CONS_MCP + u.cons_MCA)/decode(U.HR_MCP,0,1,U.HR_MCP),
		nvl_inicial,nvl_final,U.TRANS_RECEB - U.TRANS_FORNEC,
		'COM'
	);
END loop;
end;