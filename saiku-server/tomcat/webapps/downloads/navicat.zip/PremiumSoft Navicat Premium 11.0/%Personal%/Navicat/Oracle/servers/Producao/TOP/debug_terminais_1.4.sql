/*
select de.*,tb_navio.dwt,TB_FILIAL.id_filial from DEBUG_TERMINAIS de, 
TB_NAVIO ,
TB_OPERACAO,
TB_FILIAL
where 
TB_OPERACAO.id_operacao = de.id_operacao and
TB_OPERACAO.ID_NAVIO = TB_NAVIO.ID_NAVIO AND
TB_FILIAL.sigla = DE.sigla_filial
ORDER BY RAZAO, de.SIGLA_FILIAL,de.ID_MANOBRA,de.ID_OPERACAO


select id_filial from TB_FILIAL where SIGLA = 'ITA'
*/
/*SELECT
ID_TERMINAL,								
ID_interfaturamento,
								VLR_LINER,
								VLR_TRAMP,
								DWT_INICIAL,
								DWT_FINAL,SIGLA_FILIAL
							FROM
								TB_SIG_INTERFATURAMENTO
							WHERE
								( (4300
									 BETWEEN DWT_INICIAL * 1000
									AND DWT_FINAL * 1000)
								)
							AND SIGLA_FILIAL = 1
							AND(
								ID_TERMINAL = 286
								OR ID_TERMINAL = -1
								--OR ID_TERMINAL IS NOT NULL
							)
							AND(
								ID_MANOBRA = 9
								OR ID_MANOBRA = -1
								--OR ID_MANOBRA IS NOT NULL
							) */

/*
SELECT DWT FROM TB_NAVIO WHERE DESCRICAO_NAVIO = 'PUFFIN ARROW'
SELECT ID_FILIAL FROM TB_FILIAL WHERE SIGLA = 'STR'
*/
/*
SELECT
ID_TERMINAL,								
ID_MARKET_SHARE,
								VLR_LINER,
								VLR_TRAMP,
								DWT_INICIAL,
								DWT_FINAL,SIGLA_FILIAL
							FROM
								TB_SIG_MARKET_SHARE
							WHERE
								( 22377
									 BETWEEN DWT_INICIAL * 1000
									AND DWT_FINAL * 1000
								)
							--AND SIGLA_FILIAL = 5
							AND(
								ID_TERMINAL = 124
								OR ID_TERMINAL = -1
								--OR ID_TERMINAL IS NOT NULL
							)
							AND(
								ID_MANOBRA = 3
								OR ID_MANOBRA = -1
								OR ID_MANOBRA = 8
							) 
*/


SELECT
										*
									FROM
										TB_SIG_INTERFATURAMENTO
									WHERE
										(
											26477 BETWEEN DWT_INICIAL * 1000
											AND DWT_FINAL * 1000
										)
									AND(
										ID_CLIENTE = 3
										OR ID_CLIENTE = -1
										OR ID_CLIENTE IS NOT NULL
									)
									--AND SIGLA_FILIAL = P_ID_FILIAL
									AND
									(
										(ID_TERMINAL = 2 OR (ID_TERMINAL = -1 AND SIGLA_FILIAL = 2) OR (ID_TERMINAL IS NOT NULL AND SIGLA_FILIAL = 2)) 
									)
									AND(
										ID_MANOBRA = 8
										OR ID_MANOBRA = -1
										OR ID_MANOBRA IS NOT NULL
									)
									AND ROWNUM = 1
									ORDER BY
										DWT_FINAL DESC ;
