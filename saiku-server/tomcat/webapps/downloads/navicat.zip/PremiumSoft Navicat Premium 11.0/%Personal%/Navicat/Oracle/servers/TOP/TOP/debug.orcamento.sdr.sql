/*
									AGO			SET
Voyage Charter		(662)	 (1.746)
Bareboat					(96)	 (96)
*/
SELECT
	*
FROM
	PRD_JJ_CARGA
WHERE
	FILIAL_ALOCACAO IN ('SDR', 'TMD')
AND mes = 8
AND ano = 2013
AND NOME_CONTA_CONTABIL LIKE '%Voyage Charter%'

/*
select * from TB_PRD_ORCAMENTO where ano = 2013 and mes = 8 and id_conta_contabil = 411210002000000 and filial_origem = 'SDR'
*/