/*select * from TB_EMPRESA
where ID_EMPRESA in(
select * from TB_SIG_INTERFATURAMENTO where VLR_LINER = 20412


select * from "DW_sn_afretamento_fato" where ID_OPERACAO = 92589
)*/

							SELECT
									ID_INTERFATURAMENTO,
									VLR_LINER,
									VLR_TRAMP 
								FROM
									TB_SIG_INTERFATURAMENTO
								WHERE
									(
										61000 BETWEEN DWT_INICIAL * 1000
										AND DWT_FINAL * 1000
									)
								AND(
									(ID_CLIENTE = 973 OR ID_CLIENTE = -1)
									OR (ID_CLIENTE IS NOT NULL)
								)
								--AND SIGLA_FILIAL = P_ID_FILIAL
								AND
								(
									(ID_TERMINAL = 157 OR (ID_TERMINAL = -1 AND SIGLA_FILIAL = 1) OR (ID_TERMINAL IS NOT NULL AND SIGLA_FILIAL = 1)) 
								)
								ORDER BY ID_CLIENTE DESC;




SELECT
									ID_INTERFATURAMENTO,
									VLR_LINER,
									VLR_TRAMP 
								FROM
									TB_SIG_INTERFATURAMENTO
								WHERE
									(
										61000 BETWEEN DWT_INICIAL * 1000
										AND DWT_FINAL * 1000
									)
								AND(
									ID_CLIENTE = 973
									OR ID_CLIENTE = -1
									OR ID_CLIENTE IS NOT NULL
								)
								--AND SIGLA_FILIAL = P_ID_FILIAL
								AND
								(
									(ID_TERMINAL = 157 OR (ID_TERMINAL = -1 AND SIGLA_FILIAL = 1) OR (ID_TERMINAL IS NOT NULL AND SIGLA_FILIAL = 1)) 
								)
								ORDER BY ID_CLIENTE DESC