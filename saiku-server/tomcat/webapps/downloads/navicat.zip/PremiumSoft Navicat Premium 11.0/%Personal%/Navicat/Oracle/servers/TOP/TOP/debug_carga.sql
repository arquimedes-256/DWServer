/* 25 SDR , 75 TMD */
select z.ANO,z.MES,z.FILIAL_ALOCACAO,
z.ID_CONTA_CONTABIL,
z.NOME_CONTA_CONTABIL,
sum(ORC.VLR_ORCADO) prev,
sum(round(realizado,2)) realizado,
(sum(ORC.VLR_ORCADO) - sum(round(realizado,2))) diferenca 
from (
SELECT ANO,MES,FILIAL_ALOCACAO,ID_CONTA_CONTABIL,NOME_CONTA_CONTABIL,
--SUM(PREV) PREV,
CASE 
	WHEN FILIAL_ALOCACAO = 'SDR' THEN 
	SUM (REALIZADO)
	WHEN FILIAL_ALOCACAO = 'TMD' THEN 
	SUM (REALIZADO)
	ELSE SUM(REALIZADO) END AS REALIZADO,
SUM(REALIZADO) DIFERENCA FROM 
(
SELECT
	*
FROM
(
		SELECT
			ANO,
			MES,
			FILIAL_ALOCACAO,
			ID_CONTA_CONTABIL,
			NOME_CONTA_CONTABIL,cod_centro_custo,
			SUM (PREV) PREV,
			CASE
		WHEN FILIAL_ALOCACAO = 'SDR' and COD_CENTRO_CUSTO = 'ED0100116' 
THEN
			SUM (
				REALIZADO * (
					SELECT
						SUM (
							realizado / (
								SELECT
									SUM (realizado)
								FROM
									PRD_DATA_COM_TEMADRE
								WHERE
									ID_CONTA_CONTABIL = 310201009000000
								AND FILIAL_ALOCACAO IN ('SDR', 'TMD') --@remove
								--AND mes = 10
								--AND ano = 2013
							)
						)
					FROM
						PRD_DATA_COM_TEMADRE
					WHERE
						ID_CONTA_CONTABIL = 310201009000000
					AND FILIAL_ALOCACAO = 'SDR'
					--AND mes = 10
					--AND ano = 2013
				)
			)
		WHEN FILIAL_ALOCACAO = 'TMD' and COD_CENTRO_CUSTO = 'ED0100116' 
THEN
			SUM (
				REALIZADO *(
					SELECT
						SUM (
							realizado / (
								SELECT
									SUM (realizado)
								FROM
									PRD_DATA_COM_TEMADRE
								WHERE
									ID_CONTA_CONTABIL = 310201009000000
								AND FILIAL_ALOCACAO IN ('SDR', 'TMD') --@remove
								--AND mes = 10
								--AND ano = 2013
							)
						)
					FROM
						PRD_DATA_COM_TEMADRE
					WHERE
						ID_CONTA_CONTABIL = 310201009000000
					AND FILIAL_ALOCACAO = 'TMD'
					--AND mes = 10
					--AND ano = 2013
				)
			)
		ELSE
			SUM (REALIZADO)
		END AS REALIZADO,
		SUM (DIFERENCA) DIFERENCA
	FROM
		(
			SELECT
				COD_CENTRO_CUSTO,
				ID_CONTA_CONTABIL,
				NOME_CONTA_CONTABIL,
				MES,
				ANO,
				PREV,
				REALIZADO,
				DIFERENCA,
				FILIAL_ALOCACAO
			FROM
				PRD_DATA_COM_TEMADRE
union ALL
			SELECT
				COD_CENTRO_CUSTO,
				ID_CONTA_CONTABIL,
				NOME_CONTA_CONTABIL,
				MES,
				ANO,
				PREV,
				REALIZADO,
				DIFERENCA,
				'TMD' FILIAL_ALOCACAO
			FROM
				PRD_DATA_COM_TEMADRE
			where 
			COD_CENTRO_CUSTO = 'ED0100116'
		) r
	GROUP BY
		ANO,
		MES,
		ID_CONTA_CONTABIL,
		FILIAL_ALOCACAO,
		NOME_CONTA_CONTABIL,cod_centro_custo
	ORDER BY
		ANO,
		MES,
		FILIAL_ALOCACAO,
		ID_CONTA_CONTABIL,
		NOME_CONTA_CONTABIL
	)
)
GROUP BY ANO,MES,ID_CONTA_CONTABIL,FILIAL_ALOCACAO,NOME_CONTA_CONTABIL
ORDER BY ANO,MES,FILIAL_ALOCACAO,ID_CONTA_CONTABIL,NOME_CONTA_CONTABIL
) z
,(
		select 
			id_orcamento,
			ano,
			mes,
			id_conta_contabil,
			vlr_orcado,
			decode(filial_origem,'RJ','RJ1',filial_origem) filial_origem
			from
				TB_PRD_ORCAMENTO
		UNION ALL
		select 
			id_orcamento,
			ano,
			mes,
			id_conta_contabil,
			vlr_orcado,
			'TMD' filial_origem
			from
				TB_PRD_ORCAMENTO
				where filial_origem = 'SDR'
		) orc
		where
		orc.mes = z.mes 
			and orc.ano = z.ano 
			and orc.filial_origem = z.filial_alocacao
			and orc.ID_CONTA_CONTABIL = z.ID_CONTA_CONTABIL
		GROUP BY z.ANO,z.MES,z.FILIAL_ALOCACAO,
		z.ID_CONTA_CONTABIL,
		z.NOME_CONTA_CONTABIL