SELECT
								ID_MARKET_SHARE,
								VLR_LINER,
								VLR_TRAMP,
								ID_TERMINAL
							FROM
								TB_SIG_MARKET_SHARE
							WHERE
								( (18315
									 BETWEEN DWT_INICIAL * 1000
									AND DWT_FINAL * 1000)
								)
							AND SIGLA_FILIAL = 3
							AND(
								ID_TERMINAL = 135
								OR ID_TERMINAL = -1
								OR ID_TERMINAL IS NOT NULL
							)
							AND(
								ID_MANOBRA = 9
								OR ID_MANOBRA = -1
								OR ID_MANOBRA IS NOT NULL
							)