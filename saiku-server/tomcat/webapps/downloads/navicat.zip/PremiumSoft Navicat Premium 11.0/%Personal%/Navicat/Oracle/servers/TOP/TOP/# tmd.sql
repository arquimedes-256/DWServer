select * from DEBUG_STABLE_GRUPOMASTER
WHERE
 NOME_ULTRAGRUPO = '-'
and
 FILIAL_ALOCACAO = 'APT'
---and ID_GRUPO = 17
--AND mes = 7
AND ano = 2013



select * from PRD
WHERE
 FILIAL_ALOCACAO = 'MAC'
and COD_CONTA_CONTABIL = 411310002000000
AND mes = 7
AND ano = 2013; -- -250064.78






SELECT
	*
FROM
	prd_jj_carga
WHERE
 FILIAL_ALOCACAO = 'APM'
AND mes = 10
AND ano = 2013;





SELECT
	o.*
FROM
	TB_PRD_ORCAMENTO o
WHERE
	ID_CONTA_CONTABIL = 482010001000000
AND FILIAL_ORIGEM = 'MTZ'
AND mes = 07
AND ano = 2013;




-----------------------------------
select * from TB_PRD_ORCAMENTO 
where ano = 2013 and mes = 10 and ID_CONTA_CONTABIL = 427010002000000
and FILIAL_ALOCACAO in( 'MAC');

select * from prd_jj_carga
where ano = 2013 and mes = 10 and ID_CONTA_CONTABIL = 427010002000000
and FILIAL_ALOCACAO in( 'MAC');