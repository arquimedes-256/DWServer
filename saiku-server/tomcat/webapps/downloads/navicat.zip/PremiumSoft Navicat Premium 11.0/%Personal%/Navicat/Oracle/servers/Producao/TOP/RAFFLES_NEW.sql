
select 
	this.mdb,
	this.DESCRICAO_REBOCADOR,
	this.DESCRICAO_MONOBRA_INGLES,
	THIS.DESCRICAO_TERMINAL,
	THIS.DESCRICAO_BERCO,
	to_char(THIS.DATA_INICIO,'DD/MM/YYYY')|| ' ' ||THIS.HORA_INICIO,
	to_char(THIS.DATA_FIM,'DD/MM/YYYY')|| ' ' ||this.HORA_FIM,
	CALCULO.VL_TARIFA,
	THIS.DESCRICAO_PORTO,
	filial.sigla,
	op.id_operacao,
	navio.descricao_navio,
	navio.dwt,
	THIS.DESCRICAO_MUNICIPIO,
	CALCULO.VL_ISS,
	calculo.vl_tarifa + vl_iss TOTAL_ORIGEM,
	CALCULO.VL_TARIFA_REAL,
	CALCULO.VL_ISS_REAL,
	calculo.VL_TARIFA_REAL + calculo.VL_ISS_REAL TOTAL_ORIGEM_REAL,
	co.vl_liquido_origem liquido_origem_total_operacao,
	co.vl_iss_origem iss_origem_total_operacao,
	co.vl_liquido_real liquido_real_total_operacao,
	co.vl_iss_real iss_real_total_operacao,
	co.vl_cambio total_real_total_operacao,
	OP.FAT_NF,
	OP.NR_FATURA,
	THIS.iss "% ISS",TO_CHAR(CO.DT_CALCULO,'MM')
from 	VW_OPERACAO_REBOCADOR this,
			TB_OPERACAO op,
			TB_CALCULO_MANOBRA calculo,
			TB_NAVIO navio,
			TB_CALCULO_OPERACAO co,
			tb_empresa empresa,
			TB_FILIAL filial
where 
	this.id_operacao = op.id_operacao
AND
	co.id_operacao = op.id_operacao
and
	CALCULO.ID_MANOBRA_OPERACAO = THIS.ID_MANOBRA_OPERACAO
and 
	CALCULO.ID_REBOCADOR = THIS.ID_REBOCADOR
and 
	empresa.id_empresa = OP.id_empresa
and 
	filial.ID_FILIAL = OP.ID_FILIAL
AND 
	op.id_navio = navio.id_navio
AND
	EMPRESA.RAZAO_SOCIAL like 'RAFFLES%'
and 
	(TO_CHAR(THIS.DATA_FIM,'YY') = 13)
and 
	(TO_CHAR(THIS.DATA_FIM,'MM') = 9 OR TO_CHAR(CO.DT_CALCULO,'MM') = 9)
    AND OP.SITUACAO IN ('F')
order by filial.sigla,THIS.ID_OPERACAO,this.DESCRICAO_MONOBRA,THIS.DESCRICAO_REBOCADOR

--select * from TB_CALCULO_MANOBRA where ID_OPERACAO = 96679;