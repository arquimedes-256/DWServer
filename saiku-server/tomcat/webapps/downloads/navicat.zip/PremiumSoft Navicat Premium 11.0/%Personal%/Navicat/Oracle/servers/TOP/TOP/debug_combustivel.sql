
 SELECT
						distinct to_char("DATA",'dd/mm/yyyy') data,
						"SALDO",
						"COMPRA",
						"ACERTO_PERDA_DESCARTE",
						"TRANS_RECEB",
						"TRANS_FORNEC",
						"CONS_MCP",
						"CONS_MCA",
						"HR_MCP",
						"HR_MCA",
						"ID_REBOCADOR",
						"TP_CONSUMO",
						"SIGLA_FILIAL",STATUS,
						(NVL("SALDO",0) + NVL("COMPRA",0) +  NVL("ACERTO_PERDA_DESCARTE",0) + NVL("TRANS_RECEB",0) - NVL("TRANS_FORNEC",0) - NVL("CONS_MCP",0) - NVL("CONS_MCA",0)) SALDO_FINAL
					FROM
						TB_SIG_COMBUSTIVEL 
where (STATUS = 'A' and
 ID_REBOCADOR = 170 and SIGLA_FILIAL = 3 
						 and to_char(DATA,'YYYY') = 2013 and to_char(data,'MM') = 11) 

--&idFilial=3&idRebocador=170&idMes=11&idAno=2013