select * from (
SELECT
	xzd."ANO",
	xzd."MES",
	xzd."ID_ULTRAGRUPO",
	xzd."NOME_ULTRAGRUPO",
	xzd."ID_SUPERGROUPO",
	xzd."NOME_SUPERGRUPO",
	xzd."ID_GRUPOMASTER",
	xzd."NAME_GRUPOMASTER",
	xzd."ID_GRUPO",
	xzd."NOME_GRUPO",
	xzd."FILIAL_ALOCACAO",
	xzd."ID_CONTA_CONTABIL",
	xzd."NOME_CONTA_CONTABIL",
	xzd."PREV",
	xzd."REALIZADO",
	XZD.ORCADO2014
FROM
	(
		SELECT
			zz.* , ORC2014.VLR_ORCADO ORCADO2014
		FROM
			(
				SELECT
					jj.ANO,
					JJ.MES,
					ug.id_ultragrupo,
					ug.nome_ultragrupo,
					sg.ID_SUPERGROUPO,
					sg.NOME_SUPERGRUPO,
					GM.ID_GRUPOMASTER,
					GM.NAME_GRUPOMASTER,
					G .ID_GRUPO,
					G .NOME_GRUPO,
					JJ.FILIAL_ALOCACAO,
					jj.ID_CONTA_CONTABIL,
					JJ.NOME_CONTA_CONTABIL,
					SUM (JJ.PREV) PREV,
					SUM (jj.REALIZADO) REALIZADO
				FROM
					TB_PRD_GRUPO G,
					TB_PRD_GRUPO_CONTA GC,
					TB_GRUPOMASTER gm,
					TB_GRUPOMASTER_GRUPO gmg,
					TB_SUPERGRUPO sg,
					SUPERGRUPO_GRUPOMASTER sggm,
					tb_ultragrupo ug,
					"ultragrupo_supergrupo" ugsg,
					(
						SELECT
							xxx.ANO,
							XXX.MES,
							XXX.ID_CONTA_CONTABIL,
							xxx.FILIAL_ALOCACAO,
							XXX.VLR_REALIZADO realizado,
							dwc.NOME_CONTA_CONTABIL,
							orcz.VLR_ORCADO prev
						FROM
							FULL_TABLE xxx,
							"DW_contacontabil" dwc,
							TB_PRD_ORCAMENTO orcz
						WHERE
							dwc.ID_CONTA_CONTABIL = xxx.ID_CONTA_CONTABIL
						and orcz.FILIAL_ORIGEM = xxx.FILIAL_ALOCACAO
						and orcz.ID_CONTA_CONTABIL = XXX.ID_CONTA_CONTABIL
						and orcz.ANO = XXX.ANO
						and orcz.MES = xxx.mes
					) jj
				WHERE
					G .TIPO_GRUPO <> 'P'
				AND JJ.ID_CONTA_CONTABIL = GC.ID_CONTA
				AND GMG.ID_GRUPO = G .ID_GRUPO
				AND gm.ID_GRUPOMASTER = GMG.ID_GRUPOMASTER
				AND G .ID_GRUPO = gc.ID_GRUPO_CONTAS
				AND GMG.ID_GRUPO = G .ID_GRUPO
				AND sg.ID_SUPERGROUPO = SGGM.ID_SUPERGRUPO
				AND SGGM.ID_GRUPOMASTER = GM.ID_GRUPOMASTER
				AND UG.id_ultragrupo = UGSG.id_ultragrupo
				AND UGSG.id_supergrupo = SG.ID_SUPERGROUPO
				GROUP BY
					jj.ANO,
					JJ.MES,
					ug.id_ultragrupo,
					ug.nome_ultragrupo,
					sg.ID_SUPERGROUPO,
					sg.NOME_SUPERGRUPO,
					GM.ID_GRUPOMASTER,
					GM.NAME_GRUPOMASTER,
					G .ID_GRUPO,
					G .NOME_GRUPO,
					JJ.FILIAL_ALOCACAO,
					jj.ID_CONTA_CONTABIL,
					JJ.NOME_CONTA_CONTABIL
				ORDER BY
					jj.ANO,
					JJ.MES,
					ug.id_ultragrupo,
					ug.nome_ultragrupo,
					sg.ID_SUPERGROUPO,
					sg.NOME_SUPERGRUPO,
					GM.ID_GRUPOMASTER,
					GM.NAME_GRUPOMASTER,
					G .ID_GRUPO,
					G .NOME_GRUPO,
					JJ.FILIAL_ALOCACAO,
					jj.ID_CONTA_CONTABIL,
					JJ.NOME_CONTA_CONTABIL
			) zz,TB_PRD_ORCAMENTO orc2014
where
			orc2014.FILIAL_ORIGEM = zz.FILIAL_ALOCACAO
		AND orc2014.MES  = zz.MES
		AND ORC2014.ID_CONTA_CONTABIL = ZZ.ID_CONTA_CONTABIL
		AND orc2014.ANO = 2014
	) xzd

)
WHERE
FILIAL_ALOCACAO = 'MAC'
and 
ID_CONTA_CONTABIL = 412210002000000
and NOME_ULTRAGRUPO = '-'
--AND mes = 7
AND ano = 2013; -- -250064.78