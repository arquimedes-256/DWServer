
SELECT
	ano,
	mes,
	FILIAL_ALOCACAO,
	cod_centro_custo,nome_centro_custo,
	cod_conta_contabil,
	nome_conta_contabil,
	SUM (VALOR_LANCAMENTO)
FROM
	(

SELECT 
							CASE
									WHEN FILIAL_ALOCACAO = 'SDR'
									AND COD_CENTRO_CUSTO in( 'ED2100AHV','ED2100AL8') THEN
										'TMD'
									ELSE
										FILIAL_ALOCACAO
									END AS FILIAL_ALOCACAO,
							COD_CENTRO_CUSTO,
							 COD_CONTA_CONTABIL,
							 COD_FORNECEDOR,
							 DATA_EMISSAO_TCP,
							 DATA_LANCAMENTO,
							 DIA,
							 MES,
							 ANO,
							 NOME_CENTRO_CUSTO,
							 NOME_CONTA_CONTABIL,
							 NOME_FORNECEDOR,
							 STATUS,
							 VALOR_LANCAMENTO FROM PRD_RECEITA 
UNION ALL
							SELECT 
							FILIAL_ALOCACAO,
							COD_CENTRO_CUSTO,
							 COD_CONTA_CONTABIL,
							 COD_FORNECEDOR,
							 DATA_EMISSAO_TCP,
							 DATA_LANCAMENTO,
							 DIA,
							 MES,
							 ANO,
							 NOME_CENTRO_CUSTO,
							 NOME_CONTA_CONTABIL,
							 NOME_FORNECEDOR,
							 STATUS,
							 VALOR_LANCAMENTO FROM 
								(
									SELECT
										CASE
									WHEN FILIAL_ALOCACAO = 'SDR'
									AND COD_CENTRO_CUSTO in( 'ED2100AHV','ED2100AL8') THEN
										'TMD'
									ELSE
										FILIAL_ALOCACAO
									END AS FILIAL_ALOCACAO,
									 PRD.ANO,
									 PRD.COD_CENTRO_CUSTO,
									 PRD.COD_CONTA_CONTABIL,
									 PRD.COD_FORNECEDOR,
									 PRD.DATA_EMISSAO_TCP,
									 PRD.DATA_LANCAMENTO,
									 PRD.DIA,
									 PRD.MES,
									 PRD.NOME_CENTRO_CUSTO,
									 PRD.NOME_CONTA_CONTABIL,
									 PRD.NOME_FORNECEDOR,
									 PRD.STATUS,
									 PRD.VALOR_LANCAMENTO
									FROM
										PRD
									) 
)
where FILIAL_ALOCACAO in('TMD','SDR') and mes = 10
GROUP BY ano,mes,FILIAL_ALOCACAO,cod_centro_custo,nome_centro_custo,nome_conta_contabil,cod_conta_contabil
ORDER BY ano,mes,FILIAL_ALOCACAO,cod_centro_custo,nome_conta_contabil,nome_centro_custo,cod_conta_contabil