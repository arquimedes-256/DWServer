SELECT * FROM VW_CALCULO_OPERACAO WHERE ID_OPERACAO = 93569


SELECT * FROM VW_FATURAMENTO WHERE ID_OPERACAO = 93569


begin
	for reg in(select * from TB_FILIAL)
	loop
		
		dbms_output.put_line(reg.sigla);

	end loop;
end;


SELECT * FROM TB_NAVIO 


SELECT * FROM VW_FATURAMENTO WHERE ID_OPERACAO = 95345