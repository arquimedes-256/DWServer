SELECT
	*
FROM
(
		SELECT
			ANO,
			MES,
			FILIAL_ALOCACAO,
			ID_CONTA_CONTABIL,
			NOME_CONTA_CONTABIL,cod_centro_custo,
			SUM (PREV) PREV,
			CASE
		WHEN FILIAL_ALOCACAO = 'SDR' and COD_CENTRO_CUSTO = 'ED0100116' 
THEN
			SUM (
				REALIZADO * (
					SELECT
						SUM (
							realizado / (
								SELECT
									SUM (realizado)
								FROM
									PRD_DATA_COM_TEMADRE
								WHERE
									ID_CONTA_CONTABIL = 310201009000000
								AND FILIAL_ALOCACAO IN ('SDR', 'TMD') --@remove
								--AND mes = 10
								--AND ano = 2013
							)
						)
					FROM
						PRD_DATA_COM_TEMADRE
					WHERE
						ID_CONTA_CONTABIL = 310201009000000
					AND FILIAL_ALOCACAO = 'SDR'
					--AND mes = 10
					--AND ano = 2013
				)
			)
		WHEN FILIAL_ALOCACAO = 'TMD' and COD_CENTRO_CUSTO = 'ED0100116' 
THEN
			SUM (
				REALIZADO *(
					SELECT
						SUM (
							realizado / (
								SELECT
									SUM (realizado)
								FROM
									PRD_DATA_COM_TEMADRE
								WHERE
									ID_CONTA_CONTABIL = 310201009000000
								AND FILIAL_ALOCACAO IN ('SDR', 'TMD') --@remove
								--AND mes = 10
								--AND ano = 2013
							)
						)
					FROM
						PRD_DATA_COM_TEMADRE
					WHERE
						ID_CONTA_CONTABIL = 310201009000000
					AND FILIAL_ALOCACAO = 'TMD'
					--AND mes = 10
					--AND ano = 2013
				)
			)
		ELSE
			SUM (REALIZADO)
		END AS REALIZADO,
		SUM (DIFERENCA) DIFERENCA
	FROM
		(
			SELECT
				COD_CENTRO_CUSTO,
				ID_CONTA_CONTABIL,
				NOME_CONTA_CONTABIL,
				MES,
				ANO,
				PREV,
				REALIZADO,
				DIFERENCA,
				FILIAL_ALOCACAO
			FROM
				PRD_DATA_COM_TEMADRE
union ALL
			SELECT
				COD_CENTRO_CUSTO,
				ID_CONTA_CONTABIL,
				NOME_CONTA_CONTABIL,
				MES,
				ANO,
				PREV,
				REALIZADO,
				DIFERENCA,
				'TMD' FILIAL_ALOCACAO
			FROM
				PRD_DATA_COM_TEMADRE
			where 
			COD_CENTRO_CUSTO = 'ED0100116'
		) r
	GROUP BY
		ANO,
		MES,
		ID_CONTA_CONTABIL,
		FILIAL_ALOCACAO,
		NOME_CONTA_CONTABIL,cod_centro_custo
	ORDER BY
		ANO,
		MES,
		FILIAL_ALOCACAO,
		ID_CONTA_CONTABIL,
		NOME_CONTA_CONTABIL
	)
WHERE
	filial_alocacao IN ('SDR', 'TMD')
AND mes = 10
AND ano = 2013
AND id_conta_contabil = 412310001000000

