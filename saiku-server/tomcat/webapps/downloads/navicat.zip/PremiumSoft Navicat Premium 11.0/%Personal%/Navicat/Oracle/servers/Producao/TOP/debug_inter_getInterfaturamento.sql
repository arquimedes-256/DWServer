/*
select distinct t.descricao,f.SIGLA,t.DESCRICAO,nm.dwt,
DW.id_terminal,
dw.id_donorebocador,
dw.id_filial,
dw.id_tipo_manobra,
dw.id_tipo_tarifacao,dw.id_operacao
from "DW_sn_afretamento_fato" dw,
TB_FILIAL f,
TB_TERMINAL t,
TB_NAVIO nm
 where 
f.ID_FILIAL = dw.ID_FILIAL
AND
nm.id_navio = dw.id_navio
and
t.ID_TERMINAL = DW.ID_TERMINAL
and
VALOR_AFRETAMENTO is null
ORDER BY F.SIGLA;

select * from TB_SIG_INTERFATURAMENTO where id_interfaturamento =	606;
select * from TB_EMPRESA where id_empresa = 941
*/

--select * from TB_FILIAL where id_filial = 2
SELECT
										*
									FROM
										TB_SIG_INTERFATURAMENTO
									WHERE
										(
											275644 BETWEEN DWT_INICIAL * 1000
											AND DWT_FINAL * 1000
										)
									AND(
										ID_CLIENTE =946--select * from TB_EMPRESA where id_empresa = 946
										OR ID_CLIENTE = -1
										OR ID_CLIENTE IS NOT NULL
									)
									AND SIGLA_FILIAL =2-- select * from tb_filial where id_filial = 6
									AND(
										ID_TERMINAL = 255	--	select * from TB_TERMINAL where ID_TERMINAL  =187
										OR ID_TERMINAL = -1
										OR ID_TERMINAL IS NOT NULL
										--	select * from TB_PORTO where id_porto =12 -- 
									)
									AND(
										ID_MANOBRA =9
										OR ID_MANOBRA = -1--select * from TB_TIPO_MANOBRA where id_tipo_manobra = 11
										-- select * from tb_---select * from TB_FILIAL where id_filial = 5
										--OR ID_MANOBRA IS NOT NULL--select * from TB_TIPO_MANOBRA where id_tipo_manobra =282
									)
									AND ROWNUM = 1;

/*
SELECT PORTO.DESCRICAO,mun.descricao
	FROM TB_TERMINAL TER,
	TB_PORTO PORTO,
	TB_MUNICIPIO MUN
	WHERE 
	PORTO.ID_PORTO = TER.ID_PORTO AND
	MUN.ID_MUNICIPIO = PORTO.ID_MUNICIPIO
	AND
	ID_TERMINAL = 13
--
SELECT * FROM TB_TERMINAL WHERE ID_TERMINAL =	196
*/