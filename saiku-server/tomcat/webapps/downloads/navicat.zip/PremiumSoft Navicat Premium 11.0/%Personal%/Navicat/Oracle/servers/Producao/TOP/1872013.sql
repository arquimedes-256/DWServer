SELECT * FROM TB_CALCULO_OPERACAO WHERE ID_OPERACAO = 95218


UPDATE TB_OPERACAO SET SITUACAO = 'F' WHERE ID_OPERACAO = 95218


SELECT * FROM VW_INVOICE WHERE ID_OPERACAO = 95218

SELECT * FROM TB_CALCULO_OPERACAO

SELECT * FROM TB_CALCULO_OPERACAO WHERE DT_CALCULO >= (SYSDATE-1)


SELECT DISTINCT t3.id_operacao
                  ,t2.sigla || '-' || t1.fat_nf || '/' || TO_CHAR( t1.fat_dtsaida, 'YY' ) AS invoice_nr
                  ,t4.descricao || ', '
                    || TO_CHAR( t1.fat_dtsaida, 'FMMonth ddth, YYYY', 'nls_date_language=american' ) AS dt_emissao
                  ,TO_CHAR( t1.dt_impressao_invoice
                           ,'FMMonth ddth, YYYY'
                           ,'nls_date_language=american'
                          ) AS dt_impressao
                  ,TO_CHAR( t3.dt_vencimento, 'MM-DD-YYYY' ) AS dt_vencimento
                  ,t2.razao_social
                  ,t2.endereco_com
                  ,t2.numero_com
                  ,t2.complemento_com
                  ,t2.bairro_com
                  ,t2.cidade_com
                  ,t2.uf_com
                  ,t2.id_filial
                  ,t2.cep_com
                  ,t2.tel_1_com
                  ,t2.fax_com 
                  ,t1.razao_cliente
                  ,DECODE( t3.nome_cliente_impressao
                          ,NULL, t1.razao_cliente
                          ,t3.nome_cliente_impressao
                         ) as dec_n
                  ,t1.descricao_navio
                  ,t1.dwt
                  ,t1.situacao
                  ,t1.nr_viagem
                  ,t3.ind_tp_faturamento
                  ,t3.id_moeda
                  ,TO_CHAR( t3.vl_desconto_real + t3.vl_desconto_origem, 'FM999G999G990D00' ) AS total_desconto
                  ,TO_CHAR( t3.vl_liquido_origem, 'FM999G999G990D00' ) AS total_manobra
                  ,TO_CHAR( t3.vl_bruto_origem + t3.vl_iss_origem, 'FM999G999G990D00' ) AS total
                  ,TO_CHAR( t3.vl_bruto_origem, 'FM999G999G990D00' ) AS vl_bruto_origem
                  ,TO_CHAR( t3.vl_desconto_origem, 'FM999G999G990D00' ) AS vl_desconto_origem
                  ,TO_CHAR( t3.vl_liquido_origem, 'FM999G999G990D00' ) AS vl_liquido_origem
                  ,TO_CHAR( t3.vl_desconto_real, 'FM999G999G990D00' ) AS vl_desconto_real
                  ,extenso_en( t3.vl_liquido_origem, 'US$' ) AS extenso_invoice
                  ,TO_CHAR( t3.vl_iss_origem, 'FM999G999G990D00' ) AS vl_iss_origem
              FROM vw_operacao t1, vw_filial t2, tb_calculo_operacao t3, tb_municipio t4
             WHERE 
--DESCOMENTAR
--t3.ind_tp_faturamento = 2
               --AND 
t1.fat_nf IS NOT NULL
               --AND t1.fat_dtsaida IS NOT NULL
               AND
 t3.id_operacao = t1.id_operacao
               AND t1.id_filial = t2.id_filial
               AND t2.id_municipio = t4.id_municipio
AND t1.id_operacao = 95218


