
declare
	TYPE VECTOR IS TABLE OF VARCHAR (3) ; 
	MESES VECTOR := VECTOR (
		'Jan',
		'Fev',
		'Mar',
		'Abr',
		'Mai',
		'Jun',
		'Jul',
		'Ago',
		'Set',
		'Out',
		'Nov',
		'Dez'
	) ;
	c number := 36;
	R varchar(255);
	W_MAX_DATA_FIM DATE := to_date('31/03/2013');
BEGIN

	FOR I IN MESES.FIRST..MESES.LAST LOOP
		insert into "DW_tempo_anomes"(ID_ANO_MES,"ordinal_col") values('2014/'||MESES(I),c);
		c := c+1;
	END LOOP;

end;

