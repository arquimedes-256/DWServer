select 
		this.object_id,ca.attribute_id,type_id,this.class_id
case a.type_id
when -1 then
	cast(oa.value as CHAR(8000))
when -2 then
	cast(oa.value as DECIMAL)
when -3 then
	cast(oa.value as DECIMAL)
end as value
		 from object this
		left outer join class c
			on c.class_id = this.class_id
		left outer join class_attribute ca
			on ca.class_id = c.class_id
		left outer join attribute a
			on ca.attribute_id = a.attribute_id
		left outer join object_attributes oa
			on this.object_id = oa.object_id and oa.attribute_id = a.attribute_id WHERE this.class_id = 1