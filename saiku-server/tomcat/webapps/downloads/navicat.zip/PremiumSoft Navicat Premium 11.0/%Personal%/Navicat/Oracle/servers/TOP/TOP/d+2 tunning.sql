select 
    distinct(z.id_operacao)
   -- ,dt_vencimento
    --,fat_nf
/*
case  
			when TO_CHAR(fat_dtsaida,'MM') in(1,2,3) then '1º Trimestre'
			 when TO_CHAR(fat_dtsaida,'MM') in(4,5,6) then '2º Trimestre'
			 when TO_CHAR(fat_dtsaida,'MM') in(7,8,9) then '3º Trimestre'
			 when TO_CHAR(fat_dtsaida,'MM') in(10,11,12) then '4º Trimestre'
end as TRIMESTRE
*/
,z.fat_dtsaida
    --,id_contrato
    ,z.num_contrato
    --,id_dom_condicao
    ,z.descricao as "Dias para Pagar"
    ,z.data_fim as "Data da Última Manobra"
    --,dias,
		,z.situacao
    ,
		case 
			when z.situacao = 'X' then 0
			else
		round(to_number(

			DIAS_UTEIS(z.data_fim,z.fat_dtsaida)-2

),0) 
		end as "Dias de Atraso"
from 
(
select 
    co.id_operacao
    ,co.dt_vencimento
    ,op.fat_nf
    ,op.fat_dtsaida
    ,op.id_contrato
    ,c.num_contrato
    ,c.id_dom_condicao
    ,d.descricao,OP.situacao,op. 
    ,max(rm.data_fim) as data_fim
    
    --,data_fim_manobra(op.id_operacao) as data_fim
    ,case 
        when d.descricao = '05 DIAS' then 5
        when d.descricao = '10 DIAS' then 10
        when d.descricao = '15 DIAS' then 15
        when d.descricao = '20 DIAS' then 20
        when d.descricao = '25 DIAS' then 25
        when d.descricao = '30 DIAS' then 30
        when d.descricao = '35 DIAS' then 35
        when d.descricao = '40 DIAS' then 40
        when d.descricao = '45 DIAS' then 45
        when d.descricao = '60 DIAS' then 60
        else 0
      end as DIAS

		from top.tb_calculo_operacao co 
		inner join top.tb_operacao op 
				on co.id_operacao = op.id_operacao
		inner join top.tb_contrato c 
				on op.id_contrato = c.id_contrato
		inner join top.tb_dominio d 
				on c.id_dom_condicao = d.id_dominio 
		inner join top.tb_manobra_operacao mo
				on op.id_operacao = mo.id_operacao
		inner join top.tb_rebocador_manobra rm
				on mo.id_manobra_operacao = rm.id_manobra_operacao
		 
		where rm.data_inicio >= TO_DATE('01/02/2014','DD/MM/YYYY')
				and rm.data_fim <= SYSDATE
				and op.fat_dtsaida is not null
				--and op.situacao <> 'X'
		group by     
				co.id_operacao
				,op.situacao
				,co.dt_vencimento
				,op.fat_nf
				,op.fat_dtsaida
				,op.id_contrato
				,c.num_contrato
				,c.id_dom_condicao
				,d.descricao
		) z,
TB_USUARIO usuario
order by TO_DATE('01/01/2014','DD/MM/YYYY')
where 