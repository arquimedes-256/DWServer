--select * from TB_PRD_GRUPO_CONTA where ID_CONTA = 412510001830000;

--select * from TB_PRD_ORCAMENTO where ID_CONTA_CONTABIL = 412510001830000;




DECLARE
COUNTER number := 999999999999999993123123432342123;
BEGIN
	for x in(
			select * from (select DISTINCT cod_conta_contabil from PRD_RECEITA union all  
			select  cod_conta_contabil from prd)
			where cod_conta_contabil not in(
			select distinct ID_CONTA_CONTABIL from TB_PRD_ORCAMENTO
)
	)
	loop
	--insert into tb_prd(ID_GRUPO_CONTAS,ID_CONTA) values(9,x.COD_CONTA_CONTABIL);
	FOR ANO IN (SELECT * FROM DW_TEMPO_ANO)
		LOOP
			FOR MES IN(SELECT * FROM "DW_TEMPO_mes")
			LOOP
				FOR F IN (SELECT * FROM TB_FILIAL)
				LOOP
								INSERT INTO TB_PRD_ORCAMENTO
								("ID_ORCAMENTO", "ID_CONTA_CONTABIL", "MES", "ANO", "VLR_ORCADO", "FILIAL_ORIGEM") 
								VALUES (COUNTER, x.COD_CONTA_CONTABIL, MES.ID_MES, ANO.ID_ANO, '0', F.SIGLA);
				END LOOP;
				COUNTER := COUNTER + 1;
			END LOOP;
		END LOOP;
	end loop;
end;


--select * from TB_PRD_ORCAMENTO where ROWNUM = 1;