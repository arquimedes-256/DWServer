select * from TB_PRD_ORCAMENTO where ID_CONTA_CONTABIL = 412310006000000
and FILIAL_ORIGEM = 'SDR'
and mes = 12;

--- AKII PRD... JJ . . cCarga
select * from PRD_JJ_CARGA
where ID_CONTA_CONTABIL = 412310006000000
and FILIAL_ALOCACAO = 'SDR'
and mes = 12

select * from DEBUG_STABLE_GRUPOMASTER
where ID_CONTA_CONTABIL = 412310006000000
and FILIAL_ALOCACAO in('SDR','TMD')
and mes = 12
and nome_ultragrupo = '-'
and ano = 2013