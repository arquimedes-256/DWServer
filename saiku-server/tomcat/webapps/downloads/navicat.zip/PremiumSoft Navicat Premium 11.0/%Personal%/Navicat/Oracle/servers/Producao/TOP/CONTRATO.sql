update TB_CONTRATO set DT_FIM = to_date('31/12/2013','DD/MM/YYYY'), SITUACAO = 'A' where NUM_CONTRATO = 'SDR000723'

çç

update tb_contrato set SITUACAO = 'X' where NUM_CONTRATO = 'SDR000484'