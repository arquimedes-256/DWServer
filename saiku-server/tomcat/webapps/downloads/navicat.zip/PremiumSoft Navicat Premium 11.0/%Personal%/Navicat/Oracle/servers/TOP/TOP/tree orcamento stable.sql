-- PRD [OK]
SELECT sum(valor_lancamento) from prd 
where 
	FILIAL_ALOCACAO IN ('SDR', 'TMD')
AND mes = 8
AND ano = 2013
AND NOME_CONTA_CONTABIL LIKE '%Voyage Charter%'


-- PRD_DATA_COM_TEMADRE [OK]
SELECT sum(realizado) from PRD_DATA_COM_TEMADRE 
where 
	FILIAL_ALOCACAO IN ('SDR', 'TMD')
AND mes = 8
AND ano = 2013
AND NOME_CONTA_CONTABIL LIKE '%Voyage Charter%'

-- PRD_JJ_CARGA []
SELECT sum(realizado) from PRD_JJ_CARGA 
where 
	FILIAL_ALOCACAO IN ('SDR', 'TMD')
AND mes = 8
AND ano = 2013
AND NOME_CONTA_CONTABIL LIKE '%Voyage Charter%'
