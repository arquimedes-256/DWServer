--alter system disconnect session '11,1877' immediate;

DECLARE plsql_block  VARCHAR(8000);
BEGIN

FOR X IN(select 'alter system kill session ''' || sid || ',' || serial# || '''' AS Z 
	from v$session where username = 'RM')
	LOOP
		--EXECUTE IMMEDIATE X.Z;
		plsql_block := X.Z;
		DBMS_OUTPUT.PUT_LINE(plsql_block);
		EXECUTE IMMEDIATE plsql_block;
	END LOOP;
END;


select *
	from v$session 
