DECLARE
   TYPE Roster IS TABLE OF VARCHAR2(15);
   names Roster := Roster('J Hamil', 'D Caruso', 'R Singh');
BEGIN
  FOR i IN names.FIRST .. names.LAST
  LOOP
     DBMS_OUTPUT.PUT_LINE(names(i));
  END LOOP;
END;