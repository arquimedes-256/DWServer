--- STABLE
DECLARE
P_IDREBOCADOR NUMBER;
DEBUG_MODE BOOLEAN := false;
BEGIN
	delete from FULL_TABLE;
	IF NOT DEBUG_MODE THEN
		DELETE FROM "DW_sn_afretamento_fato" WHERE SISTEMA_ORIGEM = 'MXM';
	END IF;
	DECLARE
		MES NUMBER;
	BEGIN
		FOR ANO IN 2013..2014
			LOOP
				FOR I IN 1..12 LOOP
					FOR X IN (SELECT ID_CONTA_CONTABIL FROM "DW_contacontabil")
					LOOP
							FOR F IN(SELECT SIGLA_FILIAL FROM "DW_filial")
							LOOP
								INSERT INTO FULL_TABLE(FILIAL_ALOCACAO,MES,VLR_REALIZADO,ID_CONTA_CONTABIL,ANO)
								VALUES(F.SIGLA_FILIAL,I,0,X.ID_CONTA_CONTABIL,ANO);
							END LOOP;
					END LOOP;
			END LOOP ;
		END LOOP;
	END ;
	BEGIN
		for JJ_K in (select ANO,FILIAL_ALOCACAO,MES,REALIZADO,ID_CONTA_CONTABIL from PRD_JJ_CARGA)
		LOOP
			INSERT INTO FULL_TABLE(FILIAL_ALOCACAO,MES,VLR_REALIZADO,ID_CONTA_CONTABIL,ANO)
			values(JJ_K.FILIAL_ALOCACAO,JJ_K.MES,JJ_K.REALIZADO,JJ_K.ID_CONTA_CONTABIL,JJ_K.ANO);
		END LOOP;
	END;
	DECLARE
		J_ID_GRUPO NUMBER := 0;
		J_ID_FILIAL NUMBER;
		COUNTER number := 1;
	BEGIN
		--
--===========================================================================================
		FOR J IN
				(
			SELECT
				"ANO",
				"MES",
				"ID_ULTRAGRUPO",
				"NOME_ULTRAGRUPO",
				"ID_SUPERGROUPO",
				"NOME_SUPERGRUPO",
				"ID_GRUPOMASTER",
				"NAME_GRUPOMASTER",
				"ID_GRUPO",
				"NOME_GRUPO",
				"FILIAL_ALOCACAO",
				"ID_CONTA_CONTABIL",
				"NOME_CONTA_CONTABIL",
				"PREV",
				"REALIZADO","ORCADO2014"
			from DEBUG_STABLE_GRUPOMASTER---DEBUG_STABLE_WPISCCONFIS--DEBUG_STABLE_WPISCCONFIS DEBUG_STABLE_GRUPOMASTER--PRD_JJ_CARGA
				)
				LOOP

					IF J.ID_CONTA_CONTABIL = 310201009000000 THEN
						J_ID_GRUPO := -1;
					ELSIF J.ID_CONTA_CONTABIL like '3%' THEN
						J_ID_GRUPO := 0;
					END IF;

					BEGIN
						SELECT ID_FILIAL INTO J_ID_FILIAL
						FROM "DW_filial"
						WHERE SIGLA_FILIAL = J.FILIAL_ALOCACAO ; 
						EXCEPTION WHEN no_data_found THEN
							NULL ;
					END ;
				BEGIN 
				IF NOT DEBUG_MODE THEN
								INSERT INTO "DW_sn_afretamento_fato" (
									ID_FATO,
									ID_CONTACONTABIL,
									ID_FILIAL,
									ID_ANO,
									ID_MES,
									ID_GRUPOCONTA,
									VLR_ORCADO,
									VLR_REALIZADO,
									VLR_DIFERENCA_ORCADO_REALIZADO,
									ID_GRUPOMASTER,
									ID_SUPERGRUPO,
									ID_ULTRAGRUPO,
									VLR_ORCADONOVO,
									SISTEMA_ORIGEM
								)
								VALUES
									(
										COUNTER,
										J.ID_CONTA_CONTABIL,
										J_ID_FILIAL,
										J.ANO,
										J.MES,
										j.id_grupo,
										J.PREV,
										J.REALIZADO *- 1,
										J.PREV - j.REALIZADO,
										j.ID_GRUPOMASTER,
										j.ID_SUPERGROUPO,
										j.ID_ULTRAGRUPO,
										j.orcado2014,
										'MXM'
									) ;
				END IF;
				END ;
				END LOOP;		
	END;
END;